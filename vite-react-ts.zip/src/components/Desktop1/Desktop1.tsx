import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './Desktop1.module.css';
import { IconFacebookIcon } from './IconFacebookIcon.js';
import { IconGoogleIcon } from './IconGoogleIcon.js';
import { IconInstagramIconIcon } from './IconInstagramIconIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 33:3 */
export const Desktop1: FC<Props> = memo(function Desktop1(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.maxMckinnonC9OCWLka764Unsplash}></div>
      <div className={classes.rectangle3}></div>
      <div className={classes.line1}></div>
      <div className={classes.yoda3}>Yoda3</div>
      <div className={classes.signUpWithEmail}>Sign up with email</div>
      <div className={classes.vIP}>VIP</div>
      <div className={classes.frame4}>
        <div className={classes.frame1}>
          <div className={classes.group4}>
            <div className={classes.rectangle2}></div>
            <div className={classes.continueWithZupass}>Continue with Zupass</div>
            <div className={classes.rectangle1}></div>
          </div>
          <div className={classes.group1}>
            <div className={classes.rectangle22}></div>
            <div className={classes.continueWithGoogle}>Continue with Google</div>
            <div className={classes.IconGoogle}>
              <IconGoogleIcon className={classes.icon} />
            </div>
          </div>
          <div className={classes.group2}>
            <div className={classes.rectangle23}></div>
            <div className={classes.continueWithFacebook}>Continue with Facebook</div>
            <div className={classes.IconFacebook}>
              <IconFacebookIcon className={classes.icon2} />
            </div>
          </div>
          <div className={classes.group3}>
            <div className={classes.rectangle24}></div>
            <div className={classes.continueWithInstagram}>Continue with Instagram</div>
            <div className={classes.IconInstagramIcon}>
              <IconInstagramIconIcon className={classes.icon3} />
            </div>
          </div>
        </div>
        <div className={classes.frame3}>
          <div className={classes.group5}>
            <div className={classes.login}>Login</div>
            <div className={classes.line2}></div>
          </div>
          <div className={classes.group9}>
            <div className={classes.frame2}>
              <div className={classes.group6}>
                <div className={classes.rectangle4}></div>
                <div className={classes.yourEmailAddress}>Your email address</div>
                <div className={classes.email}>Email</div>
              </div>
              <div className={classes.group7}>
                <div className={classes.rectangle42}></div>
                <div className={classes.yourPassword}>Your password</div>
                <div className={classes.password}>Password</div>
              </div>
            </div>
            <div className={classes.forgotPassword}>Forgot password?</div>
            <div className={classes.rectangle5}></div>
            <div className={classes.login2}>login</div>
          </div>
        </div>
      </div>
    </div>
  );
});
