import { memo, SVGProps } from 'react';

const IconFacebookIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 35 35' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M29.75 0H5.25C2.35051 0 0 2.35051 0 5.25V29.75C0 32.6495 2.35051 35 5.25 35H29.75C32.6495 35 35 32.6495 35 29.75V5.25C35 2.35051 32.6495 0 29.75 0Z'
      fill='#1877F2'
    />
    <path
      d='M24.3086 22.5586L25.0879 17.5H20.2343V14.2187C20.2343 12.8379 20.9111 11.4844 23.0849 11.4844H25.2929V7.17773C25.2929 7.17773 23.29 6.83593 21.3759 6.83593C17.3769 6.83593 14.7656 9.25585 14.7656 13.6445V17.5H10.3222V22.5586H14.7656V35H20.2343V22.5586H24.3086Z'
      fill='white'
    />
  </svg>
);
const Memo = memo(IconFacebookIcon);
export { Memo as IconFacebookIcon };
