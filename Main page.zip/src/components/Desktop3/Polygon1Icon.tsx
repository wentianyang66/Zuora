import { memo, SVGProps } from 'react';

const Polygon1Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 25 25' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M12.5 0L23.3253 18.75H1.67468L12.5 0Z' fill='white' />
  </svg>
);
const Memo = memo(Polygon1Icon);
export { Memo as Polygon1Icon };
