import { memo, SVGProps } from 'react';

const IconMessageIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 25 25' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M0 24.0132V2.77778C0 1.24365 1.24365 0 2.77778 0H22.2222C23.7564 0 25 1.24365 25 2.77778V16.6667C25 18.2008 23.7564 19.4444 22.2222 19.4444H6.89062C6.04678 19.4444 5.24869 19.8281 4.72154 20.4869L1.48406 24.5338C0.991958 25.1489 0 24.801 0 24.0132Z'
      fill='#DCDCDC'
    />
  </svg>
);
const Memo = memo(IconMessageIcon);
export { Memo as IconMessageIcon };
