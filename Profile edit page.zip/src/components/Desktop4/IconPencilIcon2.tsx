import { memo, SVGProps } from 'react';

const IconPencilIcon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 40 40' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M6.66667 33.3335H13.3333L30.8333 15.8335C31.7174 14.9495 32.214 13.7504 32.214 12.5002C32.214 11.2499 31.7174 10.0509 30.8333 9.16684C29.9493 8.28279 28.7502 7.78613 27.5 7.78613C26.2498 7.78613 25.0507 8.28279 24.1667 9.16684L6.66667 26.6668V33.3335Z'
      stroke='#B2B2B2'
      strokeWidth={4}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
    <path
      d='M22.5 10.8333L29.1667 17.5'
      stroke='#B2B2B2'
      strokeWidth={4}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);
const Memo = memo(IconPencilIcon2);
export { Memo as IconPencilIcon2 };
