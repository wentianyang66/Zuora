import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './Desktop4.module.css';
import { IconMessageCircleOutlineIcon } from './IconMessageCircleOutlineIcon.js';
import { IconPencilIcon2 } from './IconPencilIcon2.js';
import { IconPencilIcon } from './IconPencilIcon.js';
import { IconSearchOutlineIcon } from './IconSearchOutlineIcon.js';
import { Rectangle7Icon } from './Rectangle7Icon.js';

interface Props {
  className?: string;
}
/* @figmaId 59:233 */
export const Desktop4: FC<Props> = memo(function Desktop4(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.zuzalu1600x9001}></div>
      <div className={classes.frame6}>
        <div className={classes.bA88091024x10241}></div>
        <div className={classes.IconMessageCircleOutline}>
          <IconMessageCircleOutlineIcon className={classes.icon} />
        </div>
      </div>
      <div className={classes.frame5}>
        <div className={classes.qA}>Q&amp;A</div>
        <div className={classes.discovery}>Discovery</div>
        <div className={classes.group10}>
          <div className={classes.rectangle6}></div>
          <div className={classes.whyZuzaluIsSoGreat}>Why Zuzalu is so great?</div>
          <div className={classes.IconSearchOutline}>
            <IconSearchOutlineIcon className={classes.icon2} />
          </div>
        </div>
      </div>
      <div className={classes.photo_2023119_173851}></div>
      <div className={classes.rectangle7}>
        <Rectangle7Icon className={classes.icon3} />
      </div>
      <div className={classes.line3}></div>
      <div className={classes.rectangle9}></div>
      <div className={classes.backToMyProfile}>Back to my profile</div>
      <div className={classes.bA88091024x102412}></div>
      <div className={classes.rectangle16}></div>
      <div className={classes.IconPencil}>
        <IconPencilIcon className={classes.icon4} />
      </div>
      <div className={classes.frame18}>
        <div className={classes.zKDevotee}>ZK Devotee</div>
        <div className={classes.group22}>
          <div className={classes.edit}>Edit</div>
          <div className={classes.IconPencil2}>
            <IconPencilIcon2 className={classes.icon5} />
          </div>
        </div>
      </div>
      <div className={classes.frame19}>
        <div className={classes.addressx}>Address: 0x......</div>
        <div className={classes.descriptionCatLover}>Description: Cat lover</div>
        <div className={classes.emailOptional}>Email (optional): </div>
      </div>
    </div>
  );
});
