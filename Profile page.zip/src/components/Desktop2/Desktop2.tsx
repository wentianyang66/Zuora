import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './Desktop2.module.css';
import { Group13Icon } from './Group13Icon.js';
import { IconMessageCircleOutlineIcon } from './IconMessageCircleOutlineIcon.js';
import { IconMessageIcon } from './IconMessageIcon.js';
import { IconSearchOutlineIcon } from './IconSearchOutlineIcon.js';
import { IconShareAltIcon } from './IconShareAltIcon.js';
import { Polygon1Icon } from './Polygon1Icon.js';
import { Rectangle7Icon } from './Rectangle7Icon.js';
import { Rectangle8Icon } from './Rectangle8Icon.js';

interface Props {
  className?: string;
}
/* @figmaId 51:2 */
export const Desktop2: FC<Props> = memo(function Desktop2(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.zuzalu1600x9001}></div>
      <div className={classes.frame6}>
        <div className={classes.bA88091024x10241}></div>
        <div className={classes.IconMessageCircleOutline}>
          <IconMessageCircleOutlineIcon className={classes.icon} />
        </div>
      </div>
      <div className={classes.frame5}>
        <div className={classes.qA}>Q&amp;A</div>
        <div className={classes.discovery}>Discovery</div>
        <div className={classes.group10}>
          <div className={classes.rectangle6}></div>
          <div className={classes.whyZuzaluIsSoGreat}>Why Zuzalu is so great?</div>
          <div className={classes.IconSearchOutline}>
            <IconSearchOutlineIcon className={classes.icon2} />
          </div>
        </div>
      </div>
      <div className={classes.photo_2023119_173851}></div>
      <div className={classes.rectangle7}>
        <Rectangle7Icon className={classes.icon3} />
      </div>
      <div className={classes.line3}></div>
      <div className={classes.rectangle8}>
        <Rectangle8Icon className={classes.icon4} />
      </div>
      <div className={classes.bA88091024x102412}></div>
      <div className={classes.zKDevotee}>ZK Devotee</div>
      <div className={classes.rectangle9}></div>
      <div className={classes.editProfile}>Edit profile</div>
      <div className={classes.frame7}>
        <div className={classes.questions1}>Questions 1</div>
        <div className={classes.answers}>
          <p className={classes.labelWrapper}>
            <span className={classes.label}>Answers </span>
            <span className={classes.label2}>0</span>
          </p>
        </div>
        <div className={classes.posts}>
          <p className={classes.labelWrapper2}>
            <span className={classes.label3}>Posts </span>
            <span className={classes.label4}>0</span>
          </p>
        </div>
      </div>
      <div className={classes.myQuestions}>My questions</div>
      <div className={classes.frame13}>
        <div className={classes.whatIsZuConnect9112023BestAnsw}>
          <p className={classes.labelWrapper3}>
            <span className={classes.label5}>What is ZuConnect? </span>
            <span className={classes.label6}>09/11/2023</span>
          </p>
          <div className={classes.textBlock}>
            <p className={classes.labelWrapper4}></p>
          </div>
          <div className={classes.textBlock2}>
            <p className={classes.labelWrapper5}>
              <span className={classes.label7}>Best Answer: </span>
            </p>
          </div>
          <div className={classes.textBlock3}>
            <p className={classes.labelWrapper6}></p>
          </div>
          <div className={classes.textBlock4}>
            <p></p>
          </div>
        </div>
        <div className={classes.group12}>
          <div className={classes.IconShareAlt}>
            <IconShareAltIcon className={classes.icon5} />
          </div>
          <div className={classes.share}>Share</div>
          <div className={classes.zuzaluLogo1}></div>
          <div className={classes.zuzaluOfficial}>Zuzalu Official</div>
        </div>
        <div className={classes.zuConnectInIstanbulJoinUsForAT}>
          ZuConnect in Istanbul. Join us for a two-week popup village where the leading innovators in crypto, AI,
          governance, decentralized science, and culture unite in …
        </div>
        <div className={classes.frame16}>
          <div className={classes.frame14}>
            <div className={classes.group14}>
              <div className={classes.rectangle10}></div>
              <div className={classes.polygon1}>
                <Polygon1Icon className={classes.icon6} />
              </div>
              <div className={classes.upvoted6k}>Upvoted 6k</div>
            </div>
            <div className={classes.group13}>
              <Group13Icon className={classes.icon7} />
            </div>
          </div>
          <div className={classes.group15}>
            <div className={classes.IconMessage}>
              <IconMessageIcon className={classes.icon8} />
            </div>
            <div className={classes._102Comments}>102 Comments</div>
          </div>
        </div>
      </div>
    </div>
  );
});
