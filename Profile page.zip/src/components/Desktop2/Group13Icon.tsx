import { memo, SVGProps } from 'react';

const Group13Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 40 39' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <rect width={40} height={39} fill='#E8E8E8' />
    <path d='M20.5 31L9.67468 12.25L31.3253 12.25L20.5 31Z' fill='#4DB1F9' />
  </svg>
);
const Memo = memo(Group13Icon);
export { Memo as Group13Icon };
